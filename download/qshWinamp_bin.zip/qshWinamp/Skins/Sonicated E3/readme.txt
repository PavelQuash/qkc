Hey,

Sonicated "E3" Edition

After what seems like an endless time, i have got approval from my friends and 
decided to stop modifying at version 3.41

I have modified this beautiful skin to (what i see as) perfection,

New features:

-Added minimised Equaliser view
-Added skin for the minibrowser
-Added skin for AVS plugin (Winamp 2.6 Full+)
-Implemented "active subwindow" shading
-Fixed the poorly skinned minimised playlist (mentioned in the addon done by stridersoft)
-Removed the "StriderSoft Addon" signs-i apologise greatly for this, but the locations of the 
 signs actually had other uses.
-Added shading to the Spectrum Analyser
-Countless minor tweaks

I apologise to both Stidersoft and YUG for not asking permission for these modifications,
you guys (or anyone else with suggestions/comments) can contact me on:

dogoth@telebot.net
or
dogoth@hotmail.com

P.S. Be sure that a version for winamp 3.x will be released when i get a hold of the 
elusive beta

____________________-History-_________________________


Heya!

+++ sonicated skin V2 +++

// changes
   * added Playlist-Editor-Skin
   * added Equalizer-Skin

// To YUG
   * I hope u aren't angry, but I love your skin and hate non skinned playlists and EQs.
   * If u r pse contact me, i don't want to make money with your skin.... (-:

// To rest of the world
   * Since skins for playlist and EQ are only used by WinAMP 2, there is no need to unzip
     the files. Just place the ZIP in ur skins folder (could be u need V2.04 but never mind).
   * No 'open file(s)' Graphic in playlist-controls. Use the big + instead.
   * Badly skinned minimized playlist. But why does anyone need the playlist minimized ???

// Contact
   * eMail: stridersoft@geocities.com
   * Home : members.tripod.de/stridersoft 
            (think most of u guys can't find anything of interest there, cause its in german)

// History
   * The original README.TXT follows:

-----

++ sonicated skin for winamp(v1.0) ++

// Display...
recommend 16bit color or higher.

// installation...
unzip into your winamp skins folder.(ex. c:\program files\winamp\Skins\ )
load up winamp and popup the window;'select skin'(=press 'Alt'+'S'),
select 'sonicated'.

// Contact...
check out my www. : " http://www1.plala.or.jp/yug/ ".
E-mail. : yuppon@yellow.plala.or.jp

thanks for your downloading.


(c)1998 YUG.