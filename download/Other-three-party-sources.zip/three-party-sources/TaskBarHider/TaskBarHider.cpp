// TaskBarHider.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <stdio.h> 
#define MAX_LOADSTRING 100
#define WM_HNOTIFYICON (WM_USER + 1111)
#define HOTKEY	 (WM_USER + 1112) 
#define LEFT_TASKBAR     1
#define RIGHT_TASKBAR    2
#define TOP_TASKBAR      3
#define BOTTOM_TASKBAR   4

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
char szKey1[12] = {'b', 'g', 'h', 'j', 'k', 'l', 'q', 'u', 'w', 'x', 'y', 'z'};
char szKey2[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
HWND hWnd;

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Settings(HWND, UINT, WPARAM, LPARAM);
BOOL				TrayMessage(HWND hDlg, DWORD dwMessage, UINT uID, HICON hIcon, PSTR pszTip);
void				ShowTaskBar(BOOL bShowTaskBar);

int nTaskBarPosition = 0;
bool bShow = false;
UINT nStartUp = BST_UNCHECKED;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TASKBARHIDER, szWindowClass, MAX_LOADSTRING);

	if(FindWindow(szWindowClass,szTitle)!=0) return FALSE;

	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_TASKBARHIDER);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_TASKBARHIDER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;//(LPCSTR)IDC_TASKBARHIDER;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

BOOL TrayMessage (HWND hDlg, DWORD dwMessage, UINT uID, HICON hIcon, PSTR pszTip) 
{ 
    BOOL res; 

    NOTIFYICONDATA tnd; 

    tnd.cbSize = sizeof(NOTIFYICONDATA); 
    tnd.hWnd = hDlg; 
    tnd.uID = uID; 

    tnd.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
    tnd.uCallbackMessage = WM_HNOTIFYICON;
    tnd.hIcon = hIcon; 

    if (pszTip) 
    { 
        lstrcpyn(tnd.szTip, pszTip, sizeof(tnd.szTip)); 
    } 
    else 
    { 
        tnd.szTip[0] = '\0'; 
    } 

    res = Shell_NotifyIcon(dwMessage, &tnd); 

    return res; 
}

void ShowTaskBar(BOOL bShowTaskBar)
{
	RECT rcWorkArea;
	RECT rcTaskBar;

	HWND hTaskBar = FindWindow("Shell_TrayWnd","");
	GetWindowRect(hTaskBar, &rcTaskBar);
	if(hTaskBar)
	{
		SystemParametersInfo(SPI_GETWORKAREA,0,(LPVOID)&rcWorkArea,0);
		int nWidth = ::GetSystemMetrics(SM_CXSCREEN);
		int nHeight = ::GetSystemMetrics(SM_CYSCREEN);
		
		if(bShowTaskBar)
		{
			switch(nTaskBarPosition)
			{
				case 0:
					return;
				case LEFT_TASKBAR:
					rcWorkArea.left += rcTaskBar.right - rcTaskBar.left;
					break;
				case RIGHT_TASKBAR:
					rcWorkArea.right -= rcTaskBar.right - rcTaskBar.left;
					break;
				case TOP_TASKBAR:
					rcWorkArea.top += rcTaskBar.bottom - rcTaskBar.top;
					break;
				case BOTTOM_TASKBAR:
					rcWorkArea.bottom -= rcTaskBar.bottom - rcTaskBar.top;
					break;
			}
			SystemParametersInfo(SPI_SETWORKAREA,0,(LPVOID)&rcWorkArea,0);
			ShowWindow(hTaskBar, SW_SHOW);
		}
		else
		{
			if(rcWorkArea.left!=0) nTaskBarPosition = LEFT_TASKBAR;
			else if(rcWorkArea.top!=0) nTaskBarPosition = TOP_TASKBAR;
			else if((rcWorkArea.right-rcWorkArea.left)<nWidth) nTaskBarPosition = RIGHT_TASKBAR;
			else if((rcWorkArea.bottom-rcWorkArea.top)<nHeight) nTaskBarPosition = BOTTOM_TASKBAR;

			rcWorkArea.left = 0;
			rcWorkArea.top = 0;
			rcWorkArea.bottom = nHeight;
			rcWorkArea.right = nWidth;
			SystemParametersInfo(SPI_SETWORKAREA,0,(LPVOID)&rcWorkArea,0);
			ShowWindow(hTaskBar, SW_HIDE);
		}
	}
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, szWindowClass, szTitle,WS_OVERLAPPEDWINDOW,
      0, 0, 0, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, SW_HIDE);
   UpdateWindow(hWnd);

	HICON hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(IDI_SMALL));
	TrayMessage(hWnd, NIM_ADD, 0, hIcon, "TaskBar Hider");

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message) 
	{
		case WM_CREATE:
         { 
			HKEY hKey = NULL;
			DWORD dwType = NULL;
			DWORD dwRes = NULL;
			DWORD dwSize = sizeof(DWORD);
			ULONG que = 0;
			SHORT nVirtualWin = 88;
			SHORT nVirtualCtrl = 65;
			LONG query = RegOpenKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\TBHider",0,KEY_ALL_ACCESS,&hKey);
			if (query == ERROR_SUCCESS)
			{
				que = RegQueryValueEx(hKey,"WinKey",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS && dwRes!=0)
				{
					if(dwRes>11) dwRes = 11;
					nVirtualWin = VkKeyScan(szKey1[dwRes]);
				}
				que = RegQueryValueEx(hKey,"CtrlShiftKey",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS && dwRes!=0)
				{
					if(dwRes>25) dwRes = 25;
					nVirtualCtrl = VkKeyScan(szKey2[dwRes]);
				}
				que = RegQueryValueEx(hKey,"System",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS && dwRes!=0)
				{
					RegisterHotKey(hWnd,HOTKEY,6,nVirtualCtrl); //CTRL+SHIFT
				}
				else RegisterHotKey(hWnd,HOTKEY,8,nVirtualWin);
			}
			else RegisterHotKey(hWnd,HOTKEY,8,88); // default:WIN+X
			if(hKey) RegCloseKey(hKey);
         } 
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case ID_APP_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case ID_APP_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case ID_SETTINGS:
					DialogBox(hInst, (LPCTSTR)IDD_DIALOG_SETTINGS, hWnd, (DLGPROC)Settings);
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;

		case WM_DESTROY:
			TrayMessage(hWnd, NIM_DELETE, 0, 0, 0); 
			UnregisterHotKey(hWnd, HOTKEY);
			PostQuitMessage(0);
			break;

		case WM_HNOTIFYICON:
			if(lParam == WM_LBUTTONDOWN || lParam==WM_RBUTTONDOWN)
			{
				HMENU hMenu = LoadMenu(hInst,MAKEINTRESOURCE(IDR_MENU_POPUP));
				HMENU hSubMenu = GetSubMenu(hMenu,0);
				if (!hMenu) break;
				if (!hSubMenu) break;

				// Display and track the popup menu
				POINT pos;
				GetCursorPos(&pos);

				TrackPopupMenu(hSubMenu, 0, pos.x, pos.y, 0, 
								 hWnd, NULL);

				// BUGFIX: See "PRB: Menus for Notification Icons Don't Work Correctly"
				PostMessage(hWnd,WM_NULL, 0, 0);
				DestroyMenu(hMenu);
			}
			break;

        case WM_HOTKEY: 
			if(wParam==HOTKEY)
			{
				ShowTaskBar(bShow);
				if(bShow) bShow = FALSE;
				else bShow = TRUE;
			}
			break;		
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

LRESULT CALLBACK Settings(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		{
			CheckRadioButton(hDlg,IDC_RADIO_CTRLSHIFT,IDC_RADIO_WIN,IDC_RADIO_WIN);
			CheckDlgButton(hDlg,IDC_CHECK_START,BST_UNCHECKED);
			HWND hCtrlShift = GetDlgItem(hDlg,IDC_COMBO_CTRLSHIFT);
			HWND hWin = GetDlgItem(hDlg,IDC_COMBO_WIN);
			HWND hStartUp = GetDlgItem(hDlg,IDC_CHECK_START);
			LPSTR lpStr = new char[2];
			for(int i=0;i<12;i++) 
			{
				lpStr[0] = szKey1[i];
				lpStr[1] = 0;
				SendMessage(hWin,CB_ADDSTRING,0,(LPARAM)(LPCTSTR)lpStr);
			}
			for(i=0;i<26;i++) 
			{
				lpStr[0] = szKey2[i];
				lpStr[1] = 0;
				SendMessage(hCtrlShift,CB_ADDSTRING,0,(LPARAM)(LPCTSTR)lpStr);
			}
			SendMessage(hWin,CB_SETCURSEL, 9,0);
			SendMessage(hCtrlShift,CB_SETCURSEL, 0,0);

			HKEY hKey = NULL;
			DWORD dwType = NULL;
			DWORD dwRes = NULL;
			DWORD dwSize = sizeof(DWORD);
			ULONG que = 0;
			LONG query = RegOpenKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\TBHider",0,KEY_ALL_ACCESS,&hKey);
			if (query == ERROR_SUCCESS)
			{
				que = RegQueryValueEx(hKey,"System",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS && dwRes !=0)	CheckRadioButton(hDlg,IDC_RADIO_CTRLSHIFT,IDC_RADIO_WIN,IDC_RADIO_CTRLSHIFT);
				que = RegQueryValueEx(hKey,"StartUp",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS  && dwRes !=0) CheckDlgButton(hDlg,IDC_CHECK_START,BST_CHECKED);
				que = RegQueryValueEx(hKey,"WinKey",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS)
				{
					if(dwRes>11) dwRes = 11;
					SendMessage(hWin,CB_SETCURSEL, dwRes,0);
				}
				que = RegQueryValueEx(hKey,"CtrlShiftKey",NULL,&dwType,(LPBYTE)&dwRes,&dwSize);
				if(que==ERROR_SUCCESS)
				{
					if(dwRes>25) dwRes = 25;
					SendMessage(hCtrlShift,CB_SETCURSEL, dwRes,0);
				}

			}
			if(hKey) RegCloseKey(hKey);
			// start up options
			nStartUp = IsDlgButtonChecked(hDlg,IDC_CHECK_START);

			return TRUE;
		}
	case WM_COMMAND:
			if(LOWORD(wParam) == IDOK)
			{
				HWND hCtrlShift = GetDlgItem(hDlg,IDC_COMBO_CTRLSHIFT);
				HWND hWin = GetDlgItem(hDlg,IDC_COMBO_WIN);
				HKEY hKey = NULL;
				DWORD dwType = NULL;
				ULONG value = 0;
				SHORT nVirtualWin = 88;// X
				SHORT nVirtualCtrl = 65;// A
				UnregisterHotKey(hWnd, HOTKEY);

				LONG query = RegOpenKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\TBHider",0,KEY_ALL_ACCESS,&hKey);
				if(query != ERROR_SUCCESS) query = RegCreateKeyEx(HKEY_CURRENT_USER,"SOFTWARE\\TBHider",NULL,REG_NONE,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,&dwType);
				if(query == ERROR_SUCCESS)
				{
					value = (LONG)SendMessage(hWin,CB_GETCURSEL,0,0);
					nVirtualWin = VkKeyScan(szKey1[value]);
					RegSetValueEx(hKey,"WinKey",NULL,REG_DWORD,(BYTE* const)&value,sizeof(DWORD));
					value = (LONG)SendMessage(hCtrlShift,CB_GETCURSEL,0,0);
					nVirtualCtrl = VkKeyScan(szKey2[value]);
					RegSetValueEx(hKey,"CtrlShiftKey",NULL,REG_DWORD,(BYTE* const)&value,sizeof(DWORD));
					value = 0;
					if(IsDlgButtonChecked(hDlg,IDC_RADIO_CTRLSHIFT) == BST_CHECKED)
					{
						RegisterHotKey(hWnd,HOTKEY,6,nVirtualCtrl);
						value = 1;
					}
					else RegisterHotKey(hWnd,HOTKEY,8,nVirtualWin);
					RegSetValueEx(hKey,"System",NULL,REG_DWORD,(BYTE* const)&value,sizeof(DWORD));
					if(IsDlgButtonChecked(hDlg,IDC_CHECK_START) == BST_CHECKED) value = 1;
					RegSetValueEx(hKey,"StartUp",NULL,REG_DWORD,(BYTE* const)&value,sizeof(DWORD));
				}
				if(hKey) RegCloseKey(hKey);

				if(nStartUp != IsDlgButtonChecked(hDlg,IDC_CHECK_START)) // modified
				{
					query = RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_ALL_ACCESS,&hKey);
					if(query == ERROR_SUCCESS)
					{
						if(IsDlgButtonChecked(hDlg,IDC_CHECK_START)==BST_CHECKED)
						{
							char szPath[MAX_PATH]; 
							GetModuleFileName(NULL, szPath, sizeof(szPath));
							RegSetValueEx(hKey, "TBHider", NULL, REG_SZ, (LPBYTE)szPath, strlen(szPath)); 
						}
						else RegDeleteValue(hKey, "TBHider");
					}
					if(hKey) RegCloseKey(hKey);
				}
								
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			else if(LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
