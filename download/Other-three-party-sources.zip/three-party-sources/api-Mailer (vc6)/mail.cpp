/*=============================================================================
*
*       Simple SMTP mailer (GUI, win32, Win API source code )
*
*       Copyright (c) 1999, 2000 Alex Shilonosov
*
*       Compiled on VisualC++ 6.0 (no packs)
*               (Windows 95/ 98/ NT/ NT2000)
*
*
*       The author of this program may be contacted at shilonosov@mail.ru (@mail.md)
*
*
*       visit:  www.shilonosov.f2s.com  ( www.shilonosov.da.ru )
*               for more source code and software.
*
*       ����������� ������� �� ����� ����. �����:
*                               ������ ����� ������, ��� ����� ����������.
*
*=============================================================================
*/

#include <stdafx.h>

HWND But,But_a,next;
SOCKET sock;
WSADATA rec;
WORD wVer;
INT err,x1;
HWND hwnd_all;
char error[50];
char text[250];
char byName[MAXGETHOSTSTRUCT];
struct sockaddr_in con,pc;
PCHAR ip2;
PHOSTENT t2;

int step = 1;
int rfc= 0;

char szClassName[] = {"Mailer"};
char szWndName[] = {"Mailer"};

CHAR helo[] =   {"helo SMTP.client.1.1\xD\xA\x0"};
CHAR frm[] =    {"MAIL FROM:\x0"};
CHAR rcpt[] =   {"RCPT TO:\x0"};
CHAR dat[] =    {"DATA\xD\xA\x0"};
CHAR end_dat[]= {'\xD','\xA','.','\xD','\xA','\x0'};
CHAR quit[] =   {"QUIT\xD\xA\x0"};

#define TO              102
#define FROM    103
#define SMTP    105
#define SMTP_IP 109
#define HELLO   115
#define MESS    106
#define LIST    108
#define SEND    100

#define msg1  183
#define msg2  184

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM,  LPARAM) ;


//*************************************************************************
// Funtions that creates controls
//
// hwnd2 -parent
// x,y,w,h - position and size.
// name - text of control
// comd - ID of controll ( its command ID )
//*************************************************************************

// create CheckBox
HWND CreateCheckB(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name, INT comd)
{
        HWND ww;

        ww = CreateWindow(
                "BUTTON",     name,       // button text
        WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX | WS_TABSTOP     ,  // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) comd,       // No menu

                (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;

}
// create Button
HWND CreateBut(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name, INT comd)
{
        HWND ww;

        ww = CreateWindowEx(WS_EX_CONTROLPARENT        ,
                "BUTTON",     name,       // button text
        WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON | WS_TABSTOP ,  // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) comd,       // No menu

                (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;
}

// create Single line EditBox
HWND CreateEdit(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name, INT comd)
{
        HWND ww;

        ww = CreateWindowEx( WS_EX_CLIENTEDGE  ,
                "EDIT",     name,       // button text
        WS_VISIBLE | WS_CHILD |WS_BORDER        | WS_TABSTOP |ES_AUTOHSCROLL                             , // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) comd,       // No menu

                (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;
}

// create Multi line EditBox
HWND CreateEditM(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name, INT comd)
{
        HWND ww;

        ww = CreateWindowEx( WS_EX_CLIENTEDGE  ,
                "EDIT",     name,       // button text
        WS_VISIBLE | WS_CHILD | WS_BORDER |  ES_MULTILINE |  WS_VSCROLL |WS_HSCROLL |WS_TABSTOP           ,  // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) comd,       // No menu

                (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;
}

// create Static Text
HWND CreateText(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name )
{
        HWND ww;

        ww = CreateWindow(
                "STATIC",     name,       // button text
        WS_VISIBLE | WS_CHILD      ,  // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) 99,       // No menu
        (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;
}

// create ListBox
HWND CreateList(HWND hwnd2, INT x, INT y, INT w, INT h, PCHAR name, INT comd )
{
        HWND ww;

        ww = CreateWindowEx( WS_EX_CLIENTEDGE  ,
                "LISTBOX",     name,       // button text
        WS_VISIBLE | WS_CHILD | LBS_HASSTRINGS | WS_VSCROLL |WS_HSCROLL | WS_GROUP              ,  // styles
        x,      y,      w,      h,       hwnd2,       // parent window
        (HMENU) comd,       // No menu
        (HINSTANCE) GetWindowLong(hwnd2, GWL_HINSTANCE),
                NULL);      // pointer not needed

        return ww;
}

//**************************************************************************
//**************************************************************************

//
// Add text line to the end of the ListBox and scroll it down to see last line.
void set_stat(char* str )
{
        SendDlgItemMessage(hwnd_all, 108,LB_ADDSTRING,0,(LPARAM)str);
        SendDlgItemMessage(hwnd_all, 108,LB_SETTOPINDEX,
                                                SendDlgItemMessage(hwnd_all, 108,LB_GETCOUNT,0,0) -1, 0);
        SendDlgItemMessage(hwnd_all, 108,WM_PAINT,0,0);
}

//
// Validate all fields (from,to, ...)
int Proverka()
{
        GetDlgItemText(hwnd_all,102,text,3);    if ( !strlen(text)) return 0;
        GetDlgItemText(hwnd_all,103,text,3);    if ( !strlen(text)) return 0;
        GetDlgItemText(hwnd_all,105,text,3);    if ( !strlen(text)) return 0;
        return 1;
}

//
// Preapre IP for connection and connect to the SMTP
// when connect SMTP answer <helo...>
//          message MSG2, FD_READ should come, then will call next_step, ...
int PrepareAddr()
{
        GetDlgItemText(hwnd_all,SMTP,text,100);
        if ( (IsDlgButtonChecked(hwnd_all,SMTP_IP) ) ) // SMTP filed contain IP of the SMTP server
        {
                con.sin_addr.s_addr=inet_addr(text);   // Connect to server immediately
                con.sin_family=AF_INET;                                 //
                con.sin_port=htons(25);
                if ( connect(sock,(struct sockaddr *)&con,sizeof(con))== SOCKET_ERROR)
                {
                        sprintf(error,"error connect: %d",WSAGetLastError());
                        set_stat(error);
                }
                return 1;
        }
        else
            {
                sprintf(error,"look for SMTP: %s",text);        // we should find out the IP of the server
                set_stat(error);                                                                // from its name and then connect
                if  ( !(WSAAsyncGetHostByName(hwnd_all, msg1, text, byName, 250 )) ) // wait for <msg1> FD_CONNECT
                {                                                                                                                                  // message with IP in byname
                        set_stat("Assync failed !");
                        return 0;
                }
                return 1;
        }
}


//
// Call WSAStartup , i.e. say to Windows that we intend to work with Sockets Sub system.
int StartSock()
{
        wVer = MAKEWORD(1, 1);
        if ( !(err= WSAStartup(wVer,&rec)) )
        {
                set_stat(rec.szDescription);
                set_stat(rec.szSystemStatus);
                set_stat("======================");
        }
        else
            {
                sprintf(error,"error WSAstarup = %d ",err);
                set_stat(error);
                return 0;
        }
        return 1;
}

//
// Open Socket
int OpenSock()
{
        if ( (sock=socket(AF_INET,SOCK_STREAM, IPPROTO_TCP))==INVALID_SOCKET )
        {
                sprintf(error,"error OpenSock = %d ",sock);
                set_stat(error);
                return 0;
        }

     gethostname(text,200);     // get IP of local host
     t2=gethostbyname(text) ;  // and show it in the title of the application
        if ( t2!=NULL )
        {
                memmove(&ip2,*t2->h_addr_list,sizeof(PCHAR));
                memmove(&pc.sin_addr.s_addr,&ip2,sizeof(PCHAR));
                sprintf(text,"ip=%s",inet_ntoa(pc.sin_addr));
                SetWindowText(hwnd_all,text);
        }
        return 1;
}

//
// close socket
int CloseSock()
{
        if ( (err= closesocket(sock))==SOCKET_ERROR)
        {
                sprintf(error,"error CloseSock = %d ",err);
                set_stat(error);
        }
        return 1;
}


//
// send data to the socket.
//  if error show it
// ret 1 = succes
int send_to(char* chr )
{
        if ( send(sock,chr,strlen(chr),0)==SOCKET_ERROR )
        {
                sprintf(error,"error send: %d",WSAGetLastError());
                set_stat(error);
                return 0;
        }
  return 1;
}

//
// main procedure which talk with SMTP server (=tell command and wait for answer)
// ++step - mean that on next call of Next_Step will execute next step of sending mail.
//
// answer come as message MSG2 (FD_READ), and then will call next_step, ...
//
int Next_Step()
{
        char str[300];

        switch ( step )
        {
                // step 1
                // tell "hello" to the server
        case 1:
                if ( (send_to(helo)) ) ++step;
                break;

                // step 2
                // tell "mail from .."
        case 2:
                strcpy(str,frm);
                GetDlgItemText(hwnd_all,FROM,text,200);
                strcat(str,"<");
                strcat(str,text);
                strcat(str,">");
                strcat(str,"\xD\xA");
                if ( (send_to(str)) ) ++step;
                break;

                // step 3
                // tell "rcpt to ..."
        case 3:
                strcpy(str,rcpt);
                GetDlgItemText(hwnd_all,TO,text,200);
                strcat(str,"<");
                strcat(str,text);
                strcat(str,">");
                strcat(str,"\xD\xA");
                if ( (send_to(str)) ) ++step;
                break;

                // before this we may send any TAGs : X-Mailer: ... ,
                //

                // step 4
                // tell "data"
        case 4:
                if ( (send_to(dat)) ) ++step;
                break;

                // step 5
                // send message body
        case 5:
                for (x1=0; x1<=SendDlgItemMessage(hwnd_all, MESS, EM_GETLINECOUNT ,0,0); ++x1)
                {
                        text[0]=200;
                        text[SendDlgItemMessage(hwnd_all, 106,EM_GETLINE ,x1,(LPARAM)text)]=0;
                        strcat(text,"\xD\xA");
                        send_to(text);
                }
                // tell "end of data .."
                if ( (send_to(end_dat)) ) ++step;
                break;

                // step 6
                // tell "by by ..."
        case 6:
                if ( (send_to(quit)) ) ++step;
                break;

                // step 7
                // close SOCKet
        case 7:
                CloseSock();
                WSACleanup();
                set_stat("finisheD !");
                step=1;
                break;
        }
        return 1;
}

int WINAPI WinMain (HINSTANCE hInstance,   HINSTANCE hPrevInstance,
        char * szCmdLine, int iCmdShow)
{
        HWND        hwnd ;
        MSG         msg ;
        WNDCLASS    wndclass ;

        wndclass.style         = 0;//  CS_HREDRAW ;

        wndclass.lpfnWndProc   = WndProc;
        wndclass.cbClsExtra    = 0;
        wndclass.cbWndExtra    = 0;
        wndclass.hInstance     = hInstance;
        wndclass.hIcon         = LoadIcon (NULL,IDI_APPLICATION ) ;
        wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW    ) ;
        wndclass.hbrBackground = (HBRUSH) COLOR_WINDOW;
        wndclass.lpszMenuName  = NULL ;
        wndclass.lpszClassName = szClassName ;

        RegisterClass (&wndclass) ;

        hwnd = CreateWindow (szClassName,         /* window class name */
                szWndName,     /* window caption */
                WS_OVERLAPPEDWINDOW     ,     /* window style */
                80,           /* initial x position */
                80,           /* initial y position */
                700,           /* initial x size */
                550,           /* initial y size */
                NULL,                    /* parent window handle */
                NULL,                    /* window menu handle */
                hInstance,               /* program instance handle */
                NULL) ;                          /* creation parameters */

        ShowWindow (hwnd, iCmdShow) ;
        UpdateWindow (hwnd) ;
        hwnd_all=hwnd;

        while (GetMessage (&msg, NULL, 0, 0))
        {
                if (msg.message==WM_KEYDOWN && msg.wParam==VK_TAB) // press TAB = move focus on the next control
                {
                        SetFocus( GetNextDlgTabItem (hwnd_all,next,0));
                        next=GetFocus();
                        continue;
                }

                TranslateMessage (&msg) ;
                DispatchMessage (&msg) ;
        }
        return msg.wParam ;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
        switch (iMsg)
        {
                // create all controls
                //
        case WM_CREATE :
                CreateBut(hwnd,140,172,90,65,"Send",SEND);
        SetFocus(next=CreateEdit(hwnd,30,10,200,25,"to@mail.ru",TO));
                CreateEdit(hwnd,30,40,200,25,"from@mail.ru",FROM);
                CreateEdit(hwnd,50,80,180,25,"mail.ru",SMTP);
                CreateCheckB(hwnd,50,105,180,25,"SMTP as IP",SMTP_IP);
                But_a=CreateEditM(hwnd,0,200,180,100,"Subject: Hello\x0D\x0A\x0D\x0A Dier friend\x0D\x0A\x0D\x0A  Good by."      ,MESS);
                CreateText(hwnd,2,13,30,25,"to");
                CreateText(hwnd,2,43,30,25,"frm");
                CreateText(hwnd,2,83,50,25,"SMTP");
                But= CreateList(hwnd,240,10,50,20,"SMTP",LIST);
                return 1 ;
                //break;

        case WM_DESTROY :
                PostQuitMessage (0) ;
                return 1 ;

                break;

                // change size of the main window,
                // do resize of the listBox and TextBox
        case WM_SIZE:
                MoveWindow(But_a,0,240,LOWORD(lParam),HIWORD(lParam)-240,1);
                MoveWindow(But,240,10,LOWORD(lParam)-240,230,1);

                break;

                // FD_CONNECT: connection established
                // FD_READ: answer from SMTP server
        case msg2:

                switch (lParam)
                {
                case FD_CONNECT:
                        set_stat("connected!");
                        break;

                case FD_READ : // answer from  SMTP server
                        x1 = 240;
                        if ( (x1=recv(sock,text,x1,0)) )
                        {
                                text[x1+1]=0;
                                set_stat(text);
                                if ( !strncmp("220",text,3) || !strncmp("250",text,3) ||
                                            !strncmp("354",text,3) || !strncmp("221",text,3) )
                                {                                       // step succeseful
                                        Next_Step();    // do next step
                                }
                                else
                                {                                       // step failed
                                        sprintf(error,"Try again!, error on stage(%d)",step);
                                        set_stat(error);
                                        closesocket(sock);
                                        WSACleanup();
                                }
                        }
                        break;
                }
                return 1;

                //  Waiting IP from DNS server ( prepare_addr function try to get IP)
                //
        case msg1:

                if ( HIWORD(lParam)!=0 )
                {  // cant find such host name
                        sprintf(error,"cant get info about host: %d",HIWORD(lParam));
                        set_stat(error);
                        return 1;
                }

                t2=(HOSTENT*)&byName;
                memmove(&ip2,*t2->h_addr_list,sizeof(PCHAR));
                memmove(&con.sin_addr.s_addr,&ip2,sizeof(PCHAR));
                set_stat((char*)inet_ntoa(con.sin_addr));
                con.sin_family=AF_INET;
                con.sin_port=htons(25);

                // Search succeseful and now we can connect ...
                if ( connect(sock,(struct sockaddr *)&con,sizeof(con))==SOCKET_ERROR )
                {
                        sprintf(error,"error connect: %d",WSAGetLastError());
                        if ( WSAGetLastError()== WSAEWOULDBLOCK )
                                sprintf(error,"Waiting response...");
                        set_stat(error);
                        // as we connect message MSG2, FD_READ should come,
                }
                return 1;

        case WM_COMMAND:
                switch( LOWORD(wParam))
                {
                case TO : // TO field changed
                        if ( HIWORD(wParam)== EN_CHANGE  )
                        {
                                char *c;
                                GetWindowText((HWND)lParam,text,100);
                                c = (char*)strchr(text,'@');
                                if (!c) return 1;
                                SetDlgItemText(hwnd,105, c+1);
                                SendMessage(GetDlgItem(hwnd,105),WM_PAINT,0,0);
                        }
                        return 1;

                case SEND : // press SEND button
                        StartSock();                   //WSAstart
                        if ( !(OpenSock())) return 0;  // socket
                        if ( !Proverka() )
                        {
                                set_stat(" <- Fill all fields !");
                                return 0;
                        }
                        if ( WSAAsyncSelect(sock, hwnd, msg2,FD_READ | FD_CONNECT)==SOCKET_ERROR)
                        {
                                set_stat("Assync failed 1!");
                                return 0;
                        }
                        step=1;
                        PrepareAddr(); // connect and wait for <hello> from SMTP,
                                       // message MSG2, FD_READ should come,
                                                   // then will call next_step, ...
                        break;

                case WM_CLOSE :
                        closesocket(sock);
                        WSACleanup();
                        break;
                }
                return 0;
        case WM_HELP:
                MessageBox(hwnd,"Simple SMTP mailer\nFill fields and press <send>\n\nAuthor: Shilonosov.A. shilonosov@mail.ru ",
                                        "Mailer Help", 0 | MB_ICONINFORMATION   );
                break;
        }

        return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
}



