#ifndef WINLIRC_VERSION

#define WINLIRC_VERSION "0.6.5"

static char id[]="WinLIRC " WINLIRC_VERSION " by <jim@jtan.com> and <baily@uiuc.edu>";	
#endif

