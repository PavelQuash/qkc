//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winlirc.rc
//
#define IDI_LIRC                        100
#define IDD_DIALOG                      101
#define IDI_LIRC_INIT                   103
#define IDR_TRAYMENU                    104
#define IDI_LIRC_ERROR                  104
#define IDI_LIRC_OK                     105
#define IDD_CONFIG                      105
#define IDI_LIRC_RECV                   106
#define IDI_LIRC_SEND                   107
#define IDD_LEARN                       108
#define IDC_CONFIG                      1000
#define IDC_PORT                        1002
#define IDC_SENSE                       1003
#define IDC_EDIT1                       1004
#define IDC_FILE                        1004
#define IDC_IRCODE_EDIT                 1004
#define IDC_BUTTON1                     1005
#define IDC_BROWSE                      1005
#define IDC_ENTER                       1005
#define IDC_HIDEME                      1005
#define IDC_LEARN                       1006
#define IDC_OUT                         1007
#define IDC_ANALYZE                     1007
#define IDC_IN                          1008
#define IDC_RAW                         1008
#define IDC_SPEED                       1011
#define IDC_VERSION                     1012
#define IDC_SENDCODE                    1013
#define IDC_REMOTE_EDIT                 1014
#define IDC_REPS_EDIT                   1015
#define IDC_CHECKANIMAX                 1016
#define IDC_CHECKTRAY                   1017
#define IDC_RADIORX                     1018
#define IDC_RADIODCD                    1019
#define IDC_VIRTPULSE                   1021
#define IDC_CHECKHARDCARRIER            1022
#define IDC_RADIODTR                    1026
#define IDC_RADIOTX                     1027
#define IDC_INVERTED                    1028
#define ID_APP_SHOW                     40002
#define ID_TRAY_TWO                     40003
#define ID_EXITLIRC                     40003
#define ID_TRAY_THREE                   40004
#define ID_TOGGLEWINDOW                 40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
