#ifndef _32mf02akd93s9j40vjs
#define _32mf02akd93s9j40vjs

#pragma once

namespace AppErrorMonitor
{
	void enter(const char *,const char *,int);
	void leave();
	void dump_stack();
};

#define SAFE(expr)\
{\
	AppErrorMonitor::enter(#expr,__FILE__,__LINE__);\
	try\
	{\
		expr;\
	}\
	catch(...)\
	{\
		throw;\
	}\
	AppErrorMonitor::leave();\
}

#define ENTER(msg) {AppErrorMonitor::enter(#msg,__FILE__,__LINE__);}
#define LEAVE() {AppErrorMonitor::leave();}

#endif //_32mf02akd93s9j40vjs
