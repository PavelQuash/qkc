#include "stdafx.h"
#include "FileCache.h"
#include "AppError.h"

#define GET_INT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			var=atoi(argv[i+1]);\
			++i;\
		}

#define GET_RECT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			for(long * ptr=&var.left,idx=1;idx<5;++idx,++ptr)\
				*ptr=atoi(argv[i+idx]);\
			var.right+=var.left;\
			var.bottom+=var.top;\
			i+=4;\
		}
#define GET_FONT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			if(var!=NULL)\
			{\
				DeleteObject(var);\
				var=NULL;\
			}\
			int f_height,\
				f_width,\
				f_weight,\
				f_italic,\
				f_underline;\
			f_height=atoi(argv[i+1]);\
			f_width=atoi(argv[i+2]);\
			f_weight=atoi(argv[i+3]);\
			f_italic=atoi(argv[i+4]);\
			f_underline=atoi(argv[i+5]);\
			var=CreateFont(f_height,f_width,0,0,f_weight,f_italic,f_underline,0,RUSSIAN_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,argv[i+6]);\
			i+=6;\
		}
#define GET_STR(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			var=strdup(argv[i+1]);\
			++i;\
		}

static int b_enable=false;

struct FILE_CACHE
{
	FILE_CACHE * next;
	void * data;
	int dsize;
	char * fname;
	FILE_CACHE()
	{
		next=0;
		data=0;
	}
	~FILE_CACHE()
	{
		if(next)
			delete next;
		if(data)
			delete data;
	}
};

FILE_CACHE * root=NULL;

static void precache_file(char * path)
{
	void * d=0;
	int ds;
	strlwr(path);
	FILE * f;
	SAFE(f=fopen(path,"rb");)
	if(f)
	{
		SAFE(fseek(f,0,SEEK_END);)
		SAFE(ds=ftell(f);)
		SAFE(fseek(f,0,SEEK_SET);)
		SAFE(fread(d=(void*)new char[ds],1,ds,f);)
		SAFE(fclose(f);)
	}
	if(d)
	{
		FILE_CACHE * item=new FILE_CACHE;
		item->data=d;
		item->dsize=ds;
		item->next=root;
		item->fname=strdup(path);
		root=item;
	}
}

static void precache_dir(char * dir)
{
	HANDLE ffh;
	WIN32_FIND_DATA ffd;

	char * dir1=new char[strlen(dir)+64];
	strcpy(dir1,dir);
	strcat(dir1,"*.*");

	SAFE(ffh=FindFirstFile(dir1,&ffd);)
	if(ffh==INVALID_HANDLE_VALUE)
	{
		return;
	}

	do
	{
		if(!strcmp(ffd.cFileName,".")||!strcmp(ffd.cFileName,".."))
			continue;
		if(ffd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)
		{
			// skip
		}
		else
		{
			static char fob[8192];
			strcpy(fob,dir);
			strcat(fob,ffd.cFileName);
			OutputDebugString("precache_file(\"");
			OutputDebugString(fob);
			OutputDebugString("\")\n");
			SAFE(precache_file(fob);)
		}
	}
	while(FindNextFile(ffh,&ffd));
	SAFE(FindClose(ffh);)
}

extern bool find_in_cache	(
							 const char * fname_,
							 void **pdata,
							 int * dsize)
{
	*pdata=NULL;
	*dsize=0;
	if(!b_enable)
	{
		return false;
	}
	char * fname=strdup(fname_);
	strlwr(fname);
	FILE_CACHE * cache=root;
	while(cache)
	{
		if(!strcmp(cache->fname,fname))
		{
			memcpy(*pdata=(void*)new char[*dsize=cache->dsize],cache->data,cache->dsize);
			OutputDebugString("cache hit :");
			OutputDebugString(fname);
			OutputDebugString("\n");
			return true;
		}
		cache=cache->next;
	}
	return false;
}

extern "C" __declspec(dllexport)
long file_cache (int argc,char ** argv)
{
	char * dir;
	for(int i=0;i<argc;++i)
	{
		dir=0;
		
		GET_INT(enable,b_enable)
		else GET_STR(precache_dir,dir);

		if(dir!=NULL)
		{
			SAFE(precache_dir(dir);)
		}
	}
	return 0;
}
