// shell5.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "wdraw.h"
#include "wViewport.h"

#include "resource.h"

#include "AppError.h"

//
HINSTANCE g_hInstance=NULL;
HWND g_hWnd=NULL;
bool g_bActive=false;
wDriver2d * g_driver2d=0;
wSurface	* g_primary=0,
			* g_backbuffer=0,
			* g_surfaces[4]={0,0,0,0};
// 0 - main.bmp
// 1 - mainctrl.bmp
// 2 - listbg.jpg
// 3 - textbg.jpg
const char * g_app_name="shell";
wViewport * g_viewport=NULL;
///////////!!!!!!!!!!!!!!!!!!!!!!!!!!!
const char * APP_VERSION="shell 5.16";
///////////!!!!!!!!!!!!!!!!!!!!!!!!!!!
//

long wParseCommand(const char * str)
{
#
	//	str is "library.object([,arg])*"
	//  command type is:
	//  extern "C" __declspec(dllexport) long (*) (int argc,char**argv);
	struct wParsedObject
	{
		HINSTANCE hModule;
		void * object;
		int		argc;
		char **	argv;
		wParsedObject()
		{
			memset(this,0,sizeof(*this));
		}
		long call()
		{
			if(object==NULL)
				return 0;
			long value_to_return;
			SAFE(value_to_return=((long(*)(int,char**))object)(argc,argv));
			return value_to_return;
		}
		void parse(const char * name)
		{
			char _lib_name[128],*lib_name=_lib_name;
			int i;
			// module name
			for(i=0,lib_name[0]=0;name[i]!='.';++i)
			{
				lib_name[i]=name[i];
			}
			lib_name[i]=0;
			++i;
			strlwr(lib_name);
			while(*lib_name==9||*lib_name==32)++lib_name;
			// check for app:
			if(!lstrcmp(lib_name,g_app_name))
			{
				// main module
				hModule=GetModuleHandle(NULL);
			}
			else
			{
				// module
				hModule=GetModuleHandle(lib_name);
			}
			//
			if(!hModule)
				return;
			//
			char obj_name[128];
			obj_name[0]=0;
			for(;name[i]!=','&&name[i]!=0;++i)
			{
				SAFE(strncat(obj_name,name+i,1));
			}
			// parse args
			if(name[i]!=0)
			{
				// count params
				argc=0;
				for(int j=0;name[j];++j)
				{
					if(name[j+i]==',')
						++argc;
				}
				argv=new char * [argc];
				j=i+1;
				static char ab[256];
				for(int q=0;q<argc;++q)
				{
					ab[0]=0;
					for(;name[j]!=','&&name[j]!=0;++j)
					{
						SAFE(strncat(ab,name+j,1));
					}
					argv[q]=strdup(ab);
					++j;
				}
			}
			//
			SAFE(object=GetProcAddress(hModule,obj_name));
		}
	};
#
	wParsedObject obj;
	SAFE(obj.parse(str));
	long return_value;
	SAFE(return_value=obj.call();)
	return return_value;
}
//

//
long wCall(const char * script)
{
	// assume version 1.0.5 script
	ENTER(wCall());
	FILE * sf;
	sf=fopen(script,"rt");
	if(sf)
	{
		char buf[512];
		unsigned char * pbuf;
		while(!feof(sf))
		{
			ENTER(ParseOneLineOfCommandFile);
			buf[0]=0;
			fgets(buf,512,sf);
			if(lstrlen(buf)==0)
				continue;
			pbuf=(unsigned char*)buf;
			pbuf+=lstrlen(buf)-1;
			while(*pbuf<=32&&pbuf>=(unsigned char*)buf)*pbuf--=0;
			if(lstrlen(buf)==0)
				continue;
			SAFE(wParseCommand(buf));
			LEAVE();
		}
		fclose(sf);
	}
	LEAVE();
	return 0;
}
//

//
extern "C" __declspec(dllexport)
long quit (int argc,char * argv[])
{
	PostMessage(g_hWnd,WM_CLOSE,0,0);
	return 0;
}
//

namespace ns_wheel_control
{
	extern int enable,div_val,reverse;
};

long CALLBACK WindowProc(HWND hWnd,UINT msg,WPARAM wP,LPARAM lP)
{
	switch(msg)
	{

	case WM_ACTIVATE:
		g_bActive=(LOWORD(wP)!=WA_INACTIVE);
		break;

	case WM_CREATE:
		ENTER(WM_CREATE);
		g_hWnd=hWnd;
		// create default driver for now...
		g_driver2d=CreateDriver2d(NULL,NULL);
		if(g_driver2d==NULL)
		{
			LEAVE();
			return -1;
		}
		ENTER(InitDriver2D());
		if(!g_driver2d->init(g_hWnd))
		{
			MessageBox(0,"Could not create display driver instance","error",MB_OK|MB_ICONSTOP);
			delete g_driver2d;
			g_driver2d=NULL;
			LEAVE();
			LEAVE();
			return -1;
		}
		LEAVE();
		//
		SAFE(g_primary=g_driver2d->create_primary());
		SAFE(g_backbuffer=g_driver2d->create_offscreen(800,600));
		{
			ENTER("Loading..." screen);
			RECT msg={0,0,800,600};
			g_primary->begin_gdi();
			HDC dc=g_primary->get_dc();
			FillRect(dc,&msg,(HBRUSH)GetStockObject(BLACK_BRUSH));
			g_primary->color(RGB(255,255,255));
			g_primary->text("Loading. Please wait...",&msg,DT_CENTER|DT_VCENTER|DT_SINGLELINE);

			SIZE sa;
			g_primary->text_extent(APP_VERSION,strlen(APP_VERSION),&sa);
			
			msg.left=msg.right-sa.cx-4;
			msg.top=msg.bottom-sa.cy-4;

			g_primary->text(APP_VERSION,&msg,0);

			g_primary->end_gdi();
			LEAVE();
		}
		{
			int stime=timeGetTime();
			ENTER(load_required_images());
			g_surfaces[0]=g_driver2d->load_image("data\\main.bmp","bitmap");
			g_surfaces[1]=g_driver2d->load_image("data\\mainctrl.bmp","bitmap");
			g_surfaces[2]=g_driver2d->load_image("data\\listbg.jpg","jpeg");
			g_surfaces[3]=g_driver2d->load_image("data\\textbg.jpg","jpeg");
			LEAVE();
			if(timeGetTime()-stime<4000)
			{
				Sleep(4000-timeGetTime()+stime);
			}
		}
		//
		SAFE(g_viewport=new wViewport);
		//
		{
			// create static controls here:
			SAFE(wCall("data\\startup"));
		}
		//
		SAFE(g_viewport->paint());
		LEAVE();
		//
		break;

	case WM_DESTROY:
		ENTER(WM_DESTROY);
		SAFE(g_viewport->destroy());
		SAFE(g_primary->release());
		if(g_driver2d!=NULL)
		{
			SAFE(delete g_driver2d);
			g_driver2d=NULL;
		}
		ShowWindow(g_hWnd,SW_HIDE);
		g_hWnd=NULL;
		PostQuitMessage(0);
		LEAVE();
		break;

	case WM_KEYDOWN:
		if(wP==VK_ESCAPE)
		{
			PostMessage(hWnd,WM_CLOSE,0,0);
		}
		break;

	case WM_LBUTTONDOWN:
		if(g_viewport)
		{
			SAFE(g_viewport->on_lbuttondown(LOWORD(lP),HIWORD(lP)));
		}
		break;

	case WM_LBUTTONUP:
		if(g_viewport)
		{
			SAFE(g_viewport->on_lbuttonup(LOWORD(lP),HIWORD(lP)));
		}
		break;

	case WM_MOUSEMOVE:
		if(g_viewport)
		{
			SAFE(g_viewport->on_mousemove(LOWORD(lP),HIWORD(lP)));
		}
		break;

	case WM_MOUSEWHEEL:
		{
			using namespace ns_wheel_control;
			if(enable)
			{
				int delta;
				SAFE(delta=HIWORD(wP));
				SAFE(delta/=div_val);
				if(delta==0)
				{
					break;
				}

				char * command=0;

				if(reverse)
				{
					delta=-delta;
				}

				if(delta>0)
				{
					SAFE(command="shel.list,scroll_down");
				}
				else
				{
					SAFE(command="shell.list,scroll_up");
					delta=-delta;
				}
				for(;delta>=0;--delta)
				{
					SAFE(wParseCommand(command));
				}
			}
		}
		break;

	case WM_NCPAINT:
		return 0;

	case WM_PAINT:
		{
			RECT ur;
			if(GetUpdateRect(hWnd,&ur,FALSE))
			{
				SAFE(g_primary->blt(&ur,g_backbuffer,&ur));
				SAFE(ValidateRect(hWnd,NULL));
			}
		}
		break;

	case WM_RBUTTONUP:
		if(g_viewport)
		{
			SAFE(g_viewport->on_rbuttonup(LOWORD(lP),HIWORD(lP)));
		}
		break;

	}
	return DefWindowProc(hWnd,msg,wP,lP);
}

const char * cszWindowClass="warhast window class\ncompiled at " __TIME__ " (" __DATE__")",
		   * cszWindowTitle="��������� �������� ����";

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	ENTER(WinMain)
	try
	{
		// part 0: initialize system environment
		g_hInstance=hInstance;
		// precache ddraw.dll because I know that it will be used
		SAFE(LoadLibrary("ddraw.dll"));


		// part 1: register main window class, I do it first because
		// I don`t want to fuck user`s view with any display mode 
		// changes before any activity become possible.
		{
			ENTER(RegisterClass)
			WNDCLASSEX wc,*pwc=&wc;
			ZeroMemory(pwc,sizeof(wc));
			wc.cbSize=sizeof(wc);
			wc.hCursor=LoadCursor(NULL,IDC_ARROW);
			wc.hInstance=g_hInstance;
			wc.hIcon=LoadIcon(g_hInstance,MAKEINTRESOURCE(IDI_ICON1));
			wc.hIconSm=LoadIcon(g_hInstance,MAKEINTRESOURCE(IDI_ICON2));
			wc.lpfnWndProc=WindowProc;
			wc.lpszClassName=cszWindowClass;
			wc.style=CS_OWNDC|CS_HREDRAW|CS_VREDRAW;
			if(!RegisterClassEx(pwc))
			{
				MessageBox(0,"Could not register main window class\nIt is possible that you`re low on resources now","error",MB_OK|MB_ICONSTOP);
				return -1;
			}
			LEAVE();
		}

		// part 2: set up display mode
		{
			SAFE(wParseCommand("shell.display_mode,800,600"));
		}

		// part 3: create window and launch message processing loop
		MSG msg;
		msg.wParam=0;
		{
			ENTER(CreateWindowEx);
	#if 1
			CreateWindowEx(0,cszWindowClass,cszWindowTitle,WS_SYSMENU|WS_POPUP|WS_VISIBLE,0,0,800,600,0,0,g_hInstance,0);
	#else
			{
				int fx,fy,cy;
				fx=GetSystemMetrics(SM_CXFRAME);
				fy=GetSystemMetrics(SM_CYFRAME);
				cy=GetSystemMetrics(SM_CYCAPTION);
	#if 1
				CreateWindowEx(0,cszWindowClass,cszWindowTitle,WS_SYSMENU|WS_VISIBLE,-fx,-fy-cy,800+2*fx,600+2*fy+cy,0,0,g_hInstance,0);
	#else
				RECT wr={0,0,800,600};
				AdjustWindowRect(&wr,WS_SYSMENU,0);
				wr.top-=cy;
				CreateWindowEx(0,cszWindowClass,cszWindowTitle,WS_SYSMENU|WS_VISIBLE,wr.left,wr.top,wr.right-wr.left,wr.bottom-wr.top,0,0,g_hInstance,0);
	#endif
			}
	#endif
			LEAVE();
			if(g_hWnd==NULL)
			{
				return -2;
			}
			while(1)
			{
				if(PeekMessage(&msg,0,0,0,PM_NOREMOVE))
				{
					if(!GetMessage(&msg,0,0,0))
						break;
					TranslateMessage(&msg);
					SAFE(DispatchMessage(&msg);)
					continue;
				}else Sleep(1);
				if(g_bActive&&(g_viewport!=NULL))
				{
					POINT pt;
					GetCursorPos(&pt);
					SAFE(g_viewport->on_mousemove(pt.x,pt.y));
					SAFE(g_viewport->update());
				}
			}
		}

		// part 4: restore default dispay settings
		SAFE(ChangeDisplaySettings(NULL,0));

		return msg.wParam;
	}
	catch(...)
	{
		AppErrorMonitor::dump_stack();
		ExitProcess(-1);
	}
	LEAVE()
	return -2000;
}


//
extern "C" __declspec(dllexport)
long display_mode(int argc,char **argv)
{
	ENTER(display_mode());
	assert(argc>=2);
	unsigned
	int width=atoi(argv[0]),
		height=atoi(argv[1]);
	{
		DEVMODE dm,display_mode;
		dm.dmSize=sizeof(dm);
		display_mode.dmSize=sizeof(dm);
		dm.dmDriverExtra=0;
		display_mode.dmDriverExtra=0;
		EnumDisplaySettings(NULL,ENUM_CURRENT_SETTINGS,&display_mode);
		{
			DEVMODE edm;
			edm.dmSize=sizeof(edm);
			edm.dmDriverExtra=0;
			std::vector<DEVMODE> devmodes;
			ENTER(EnumDisplaySettings)
			for(int i=0,j=1;j;++i)
			{
				SAFE(j=EnumDisplaySettings(NULL,i,&edm);)
				if(j)
					devmodes.push_back(edm);
			}
			LEAVE();
			DEVMODE chosen=display_mode;
			int nf=0;
			ENTER(FindDisplayMode)
			for(std::vector<DEVMODE>::iterator iter=devmodes.begin();iter!=devmodes.end();++iter)
			{
				DEVMODE mode=*iter;
				if(mode.dmPelsWidth!=width)
					continue;
				if(mode.dmPelsHeight!=height)
					continue;
				if(	(mode.dmBitsPerPel!=15)&&
					(mode.dmBitsPerPel!=16)&&
					(mode.dmBitsPerPel!=24)&&
					(mode.dmBitsPerPel!=32) )
					continue;
				if( (display_mode.dmBitsPerPel!=15)&&
					(display_mode.dmBitsPerPel!=16)&&
					(display_mode.dmBitsPerPel!=24)&&
					(display_mode.dmBitsPerPel!=32) )
				{
					if(mode.dmBitsPerPel!=display_mode.dmBitsPerPel)
						continue;
				}
				if(	  (display_mode.dmDisplayFrequency==0)
					||(display_mode.dmDisplayFrequency==1)
					)
				{
					if((mode.dmDisplayFrequency!=0)&&
						(mode.dmDisplayFrequency!=1))
						continue;
				}
				else
				{
					if(mode.dmDisplayFrequency>display_mode.dmDisplayFrequency)
						continue;
				}
				if(!nf)
					chosen=mode;
				else
				{
					if(mode.dmDisplayFrequency>chosen.dmDisplayFrequency)
						chosen=mode;
				}
				++nf;
			}
			LEAVE();
			if(nf)
			{
				SAFE(ChangeDisplaySettings(&chosen,CDS_FULLSCREEN);)
				LEAVE();
				return 0;
			}
		}
		if(!(display_mode.dmPelsWidth==width&&display_mode.dmPelsHeight==height&&(display_mode.dmBitsPerPel==32||display_mode.dmBitsPerPel==24||display_mode.dmBitsPerPel==16||display_mode.dmBitsPerPel==15)))
		{
			dm.dmPelsWidth=width;
			dm.dmPelsHeight=height;
			dm.dmFields=DM_PELSWIDTH|DM_PELSHEIGHT|DM_BITSPERPEL;
			long cds_result;
			dm.dmBitsPerPel=32;
			SAFE(cds_result=ChangeDisplaySettings(&dm,CDS_FULLSCREEN);)
			if( cds_result!=DISP_CHANGE_SUCCESSFUL )
			{
				dm.dmBitsPerPel=24;
				SAFE(cds_result=ChangeDisplaySettings(&dm,CDS_FULLSCREEN);)
			}
			if( cds_result!=DISP_CHANGE_SUCCESSFUL )
			{
				dm.dmBitsPerPel=16;
				SAFE(cds_result=ChangeDisplaySettings(&dm,CDS_FULLSCREEN);)
			}
			if( cds_result!=DISP_CHANGE_SUCCESSFUL )
			{
				dm.dmBitsPerPel=15;
				SAFE(cds_result=ChangeDisplaySettings(&dm,CDS_FULLSCREEN);)
			}
			if( cds_result!=DISP_CHANGE_SUCCESSFUL )
			{
				char msg[512];
				wsprintf(msg,"Could not change display mode to %i by %i true-color or high-color. Application will now exit to prevent unpredictable behavior.",width,height);
				MessageBox(0,msg,"FATAL ERROR",MB_OK);
				LEAVE();
				return 0;
			}
			memcpy(&display_mode,&dm,sizeof(dm));
		}
	}
	LEAVE();
	return 0;
}
//
