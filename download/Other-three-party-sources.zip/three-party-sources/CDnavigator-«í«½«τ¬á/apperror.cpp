#include "stdafx.h"
#include "apperror.h"

#include <string>

namespace AppErrorMonitor
{
	std::vector<std::string> expr_stack;
	std::vector<std::string> src_file;
	std::vector<int> src_line;
	void enter(const char * msg,const char * src,int line)
	{
		try
		{
			expr_stack.push_back(msg);
			src_file.push_back(src);
			src_line.push_back(line);
		}
		catch(...)
		{
			__asm int 3;
			ExitProcess(-3);
		}
	}
	void leave()
	{
		try
		{
			expr_stack.pop_back();
			src_file.pop_back();
			src_line.pop_back();
		}
		catch(...)
		{
			__asm int 3;
			ExitProcess(-3);
		}
	}
	void dump_stack()
	{
		std::string ser="call stack dump:\n";
		std::vector<int>::iterator iit=src_line.begin();
		int i=0;
		for(std::vector<std::string>::iterator iter=expr_stack.begin(),iter2=src_file.begin();iter!=expr_stack.end();++iter,++iter2,++iit,++i)
		{
			char buf[32],buf1[32];
			sprintf(buf,"%i",*iit);
			sprintf(buf1,"[%i] ",i);
			ser=ser 
				+ buf1
				+ (*iter) 
				+ " file " 
				+ (*iter2)
				+ " line " 
				+ buf
				+ "\n";
		}
		{
			if(OpenClipboard(NULL))
			{
				HANDLE hMem=GlobalAlloc(GHND,strlen(ser.c_str())+32);
				void * mptr=GlobalLock(hMem);
				strcpy((char*)mptr,ser.c_str());
				GlobalUnlock(hMem);
				EmptyClipboard();
				SetClipboardData(CF_TEXT,hMem);
				CloseClipboard();
				ser=ser + "this information is available in clipboard";
			}
		}
		::MessageBox(::GetActiveWindow(),ser.c_str(),"error",MB_OK|MB_TASKMODAL);
	}
};