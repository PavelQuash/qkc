#if !defined(AFX_WVIEWPORT_H__CF31E74A_6FFC_424F_9C47_3ADBB67C35C2__INCLUDED_)
#define AFX_WVIEWPORT_H__CF31E74A_6FFC_424F_9C47_3ADBB67C35C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "wdraw.h"

struct wControl
{
	wControl *	next;
	int			tag;
	wSurface *	surface;
	RECT		place;
	virtual ~wControl();
	wControl();
	virtual void paint();
	virtual bool is_topmost();
	virtual void on_lbuttonup(int x,int y);
	virtual void on_lbuttondown(int x,int y);
	virtual void update();
	virtual bool hit(int x,int y);
	virtual void on_mousemove(int x,int y);
public:
	virtual void on_rbuttonup(int x,int y);
};

class wViewport  
{
public:
	void on_rbuttonup(int x,int y);
	virtual void update();
	virtual void insert_topmost(wControl * ptr);
	virtual void on_lbuttonup(int x,int y);
	virtual void on_lbuttondown(int x,int y);
	virtual void on_mousemove(int x,int y);
	void insert(wControl * ptr);
	virtual void paint();
	virtual void destroy();
	virtual void remove_controls(int tag);
	wControl * controls;
	wViewport();
	virtual ~wViewport();
};

#endif // !defined(AFX_WVIEWPORT_H__CF31E74A_6FFC_424F_9C47_3ADBB67C35C2__INCLUDED_)
