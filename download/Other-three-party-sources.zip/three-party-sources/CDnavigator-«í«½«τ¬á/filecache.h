#ifndef _FileCache_h_0932j92jr923r
#define _FileCache_h_0932j92jr923r
#pragma once
//
extern bool find_in_cache(const char * fname,void **pdata,int * dsize);
//
#endif
