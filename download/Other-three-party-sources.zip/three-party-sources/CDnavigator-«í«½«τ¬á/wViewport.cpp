#include "stdafx.h"
#include "wViewport.h"
#include "AppError.h"

#define GET_INT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			var=atoi(argv[i+1]);\
			++i;\
		}

#define GET_RGB(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			var=RGB(atoi(argv[i+1],atoi(argv[i+2]),atoi(argv[i+3]));\
			i+=3;\
		}

#define GET_RECT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			for(long * ptr=&var.left,idx=1;idx<5;++idx,++ptr)\
				*ptr=atoi(argv[i+idx]);\
			var.right+=var.left;\
			var.bottom+=var.top;\
			i+=4;\
		}
#define GET_FONT(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			if(var!=NULL)\
			{\
				DeleteObject(var);\
				var=NULL;\
			}\
			int f_height,\
				f_width,\
				f_weight,\
				f_italic,\
				f_underline;\
			f_height=atoi(argv[i+1]);\
			f_width=atoi(argv[i+2]);\
			f_weight=atoi(argv[i+3]);\
			f_italic=atoi(argv[i+4]);\
			f_underline=atoi(argv[i+5]);\
			SAFE(var=CreateFont(f_height,f_width,0,0,f_weight,f_italic,f_underline,0,RUSSIAN_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,argv[i+6]);)\
			i+=6;\
		}
#define GET_STR(name,var)\
		if(!strcmp(argv[i],#name))\
		{\
			var=strdup(argv[i+1]);\
			++i;\
		}

extern wSurface	*	g_primary,
				*	g_backbuffer,
				*	g_surfaces[4];
extern wViewport * g_viewport;
extern HWND g_hWnd;
extern wDriver2d * g_driver2d;

wViewport::wViewport()
{
	controls=0;
}

wViewport::~wViewport()
{
	// destroy controls
	if(controls)
	{
		for(wControl * ptr=controls;ptr;)
		{
			wControl * temp=ptr->next;
			SAFE(delete ptr);
			ptr=temp;
		}
	}
}

void wViewport::remove_controls(int tag)
{
	ENTER(wViewport::remove_controls());
	while(controls)
	{
		if(controls->tag!=tag)
			break;
		wControl * temp=controls->next;
		SAFE(delete controls);
		controls=temp;
	}
	wControl * ptr=controls;
	if(ptr)
	{
		while(ptr->next)
		{
			if(ptr->next->tag==tag)
			{
				wControl * temp=ptr->next;
				ptr->next=temp->next;
				SAFE(delete temp);
			}
			else
			{
				SAFE(ptr=ptr->next);
			}
		}
	}
	LEAVE();
}

void wViewport::destroy()
{
	delete this;
}

wControl::~wControl()
{

}

extern "C" __declspec(dllexport)
long static_image(int argc,char *argv[])
{
#
	struct wStaticImage: public wControl
	{
		virtual ~wStaticImage()
		{
			if(surface)
			{
				SAFE(surface->release());
			}
		}
		virtual void paint()
		{
			SAFE(g_backbuffer->blt(&place,surface,&src));
		}
		RECT src;
		wStaticImage(const RECT * _place,wSurface * _surface,const RECT * _src)
			:wControl()
		{
			surface=_surface;
			memcpy(&place,_place,sizeof(place));
			memcpy(&src,_src,sizeof(src));
			SAFE(surface->add_ref());
		}
	};
#
	if(g_viewport==NULL)return 0;
	RECT	place,
			src;
	wSurface * surface=g_backbuffer;
	int tag=0;
	for(int i=0;i<argc;)
	{
		if(!lstrcmp(argv[i],"img"))
		{
			++i;
			surface=g_surfaces[atoi(argv[i])];
			++i;
		}
		else GET_RECT(place,place)
		else GET_RECT(src,src)
		else GET_INT(tag,tag)
		else ++i;
	}
	wStaticImage * img=new wStaticImage(&place,surface,&src);
	if(tag)	img->tag=tag;
	SAFE(g_viewport->insert(img));
	return 1;
}


void wControl::paint()
{
	// do nothing here
}

void wViewport::paint()
{
	if(controls)
	{
		if(controls->is_topmost())
		{
			SAFE(controls->paint());
		}
		else
		{
			for(wControl * ptr=controls;ptr;ptr=ptr->next)
			{
				SAFE(ptr->paint());
			}
		}
	}
	SAFE(g_primary->blt(0,g_backbuffer,0));
}

void wViewport::insert(wControl *ptr)
{
	if(controls==NULL)
	{
		SAFE(controls=ptr);
	}
	else
	{
		wControl * c=controls;
		SAFE(while(c->next)c=c->next;)
		SAFE(c->next=ptr;)
	}
}

wControl::wControl()
{
	next=0;
	memset(&place,0,sizeof(place));
	tag=0;
	surface=0;
}

extern long wCall(const char*);

extern "C" __declspec(dllexport)
long button(int argc,char * argv[])
{
#
	struct wButton: public wControl
	{
		RECT src;
		char * cmd;
		int state;
		wButton(const RECT * _place,wSurface * _surface,const RECT * _src,const char * _cmd)
			:wControl()
		{
			memcpy(&place,_place,sizeof(place));
			memcpy(&src,_src,sizeof(src));
			surface=_surface;
			SAFE(surface->add_ref();)
			SAFE(cmd=strdup(_cmd);)
			state=0;
		}
		virtual ~wButton()
		{
			if(surface)
			{
				SAFE(surface->release();)
			}
		}
		void paint()
		{
			RECT sr;
			memcpy(&sr,&src,sizeof(sr));
			OffsetRect(&sr,state*(src.right-src.left),0);
			SAFE(g_backbuffer->blt(&place,surface,&sr);)
		}
		void set_state(int st)
		{
			if(st!=state)
			{
				state=st;
				SAFE(paint();)
				SAFE(update();)
			}
		}
		void on_mousemove(int x,int y)
		{
			if(hit(x,y))
			{
				if(state==0)
				{
					SAFE(set_state(1);)
				}
			}
			else
			{
				SAFE(set_state(0);)
			}
		}
		void on_lbuttondown(int x,int y)
		{
			if(hit(x,y))
			{
				SAFE(set_state(2);)
			}
			else
			{
				SAFE(set_state(0);)
			}
		}
		void on_lbuttonup(int x,int y)
		{
			if(hit(x,y))
			{
				if(state==2)
				{
					SAFE(wCall(cmd);)
				}
				SAFE(set_state(1);)
			}
			else
			{
				SAFE(set_state(0);)
			}
		}
	};
#
	if(g_viewport==NULL)return 0;
	RECT	place,
			src;
	wSurface * surface=g_backbuffer;
	int tag=0;
	char * cmd="";
	for(int i=0;i<argc;)
	{
		if(!lstrcmp(argv[i],"img"))
		{
			++i;
			surface=g_surfaces[atoi(argv[i])];
			++i;
		}
		else GET_RECT(place,place)
		else GET_RECT(src,src)
		else GET_INT(tag,tag)
		else if(!lstrcmp(argv[i],"cmd"))
		{
			++i;
			cmd=argv[i];
			++i;
		}
		else ++i;
	}
	wButton * img=new wButton(&place,surface,&src,cmd);
	if(tag)	img->tag=tag;
	g_viewport->insert(img);
	return 1;
}

namespace ns_wheel_control
{
	int	enable=0,
		div_val=1,
		reverse=0;
};

extern "C" __declspec(dllexport)
long wheel(int argc,char * argv[])
{
	ENTER(shell.wheel);
	using namespace ns_wheel_control;
	for(int i=0;i<argc;++argv)
	{
		GET_INT(enable,enable)
		else GET_INT(div,div_val)
		else GET_INT(reverse,reverse);
	}
	LEAVE();
	return 1;
}

void wControl::on_mousemove(int x, int y)
{
	//
}

bool wControl::hit(int x, int y)
{
	//
	POINT pt={x,y};
	return PtInRect(&place,pt)!=0;
}

void wViewport::on_mousemove(int x, int y)
{
	for(wControl * ptr=controls;ptr;ptr=ptr->next)
	{
		SAFE(ptr->on_mousemove(x,y);)
		if(ptr->is_topmost())
			break;
	}
}

void wControl::update()
{
	SAFE(g_primary->blt(&place,g_backbuffer,&place);)
}

void wControl::on_lbuttondown(int x, int y)
{

}

void wControl::on_lbuttonup(int x, int y)
{

}

void wViewport::on_lbuttondown(int x, int y)
{
	if(controls->is_topmost())
	{
		SAFE(controls->on_lbuttondown(x,y);)
		return;
	}
	for(wControl * ptr=controls;ptr;ptr=ptr->next)
	{
		SAFE(ptr->on_lbuttondown(x,y);)
	}
}

void wViewport::on_lbuttonup(int x, int y)
{
	if(controls->is_topmost())
	{
		SAFE(controls->on_lbuttonup(x,y);)
		return;
	}
	for(wControl * ptr=controls;ptr;ptr=ptr->next)
	{
		SAFE(ptr->on_lbuttonup(x,y);)
	}
}

extern "C" __declspec(dllexport)
long kill_controls (int argc,char ** argv)
{
	if(g_viewport==0)return 0;
	for(int i=0;i<argc;++i)
	{
		SAFE(g_viewport->remove_controls(atoi(argv[i]));)
	}
	SAFE(g_viewport->paint();)
	return 0;
}

namespace ns_list
{
	void * current_list=NULL;
	static RECT		place={0,0,1,1};//construction-time
	static RECT		text_place={0,0,1,1};//run-time
	static HFONT	font=0;//run-time
	static int		line_step=10;//run-time
	static int		visible_lines=10;//run-time?
	static int		color_t1=RGB(255,255,255),//run-time
					color_s1=RGB(128,128,128),//run-time
					color_t2=RGB(128,128,128),//run-time
					color_s2=RGB(32,32,32),//run-time
					color_t3=RGB(0,0,0),//run-time
					color_s3=RGB(64,64,64);//run-time
	char * action=0;
};

extern long wParseCommand(const char*);

extern "C" __declspec(dllexport)
long list(int argc,char * argv[])
{
#
struct wList: public wControl
{
	int n_items;
	int top_line;
	char ** items;
	char * base_name;
	int sel_line;
	int sel_state;
	bool load(const char * name)
	{
		ENTER(wList::load());
		base_name=strdup(name);
		static char lst[512];
		strcpy(lst,base_name);
		strcat(lst,".lst");
		FILE * f=fopen(lst,"rt");
		if(f==NULL)
			return false;
		fgets(lst,512,f);
		n_items=atoi(lst);
		items=new char *[n_items];
		for(int i=0;i<n_items;++i)
		{
			fgets(lst,512,f);
			unsigned char * ptr=(unsigned char *)lst;
			while(*ptr)++ptr;
			while(*ptr<=32&&(char*)ptr>=lst)*ptr--=0;
			items[i]=strdup(lst);
		}
		fclose(f);
		LEAVE();
		return true;
	}
	void on_mousemove(int x,int y)
	{
		using namespace ns_list;
		bool repaint=false;
		if(hit_line(x,y)!=sel_line)
		{
			if(sel_state)
			{
				sel_state=0;
				repaint=true;
			}
			if(hit_line(x,y)>=0&&hit_line(x,y)<visible_lines&&hit_line(x,y)<n_items)
			{
				sel_line=hit_line(x,y);
				sel_state=1;
				repaint=true;
			}
		}
		else if (sel_state==0)
		{
			sel_state=1;
			repaint=true;
		}
		if(repaint)
		{
			SAFE(paint();)
			SAFE(g_primary->blt(&place,g_backbuffer,&place);)
		}
	}
	void on_lbuttondown(int x,int y)
	{
		using namespace ns_list;
		bool repaint=false;
		if(hit_line(x,y)>=0&&hit_line(x,y)<visible_lines&&hit_line(x,y)<n_items)
		{
			sel_line=hit_line(x,y);
			sel_state=2;
			repaint=true;
		}
		else SAFE(on_mousemove(x,y);)
		if(repaint)
		{
			SAFE(paint();)
			SAFE(g_primary->blt(&place,g_backbuffer,&place);)
		}
	}
	void on_lbuttonup(int x,int y)
	{
		using namespace ns_list;
		bool repaint=false;
		if(hit_line(x,y)==sel_line&&sel_state==2)
		{
			sel_state=1;
			if(action)
			{
				static char cmd[256],t[64];
				SAFE(strcpy(cmd,action);)
				SAFE(wsprintf(t,",%s,%i",base_name,top_line+sel_line);)
				SAFE(strcat(cmd,t);)
				SAFE(wParseCommand(cmd);)
			}
			else
			{
				MessageBox(::GetActiveWindow(),"no list item action specified",0,MB_OK);
			}
			repaint=true;
		}
		else SAFE(on_mousemove(x,y);)
		if(repaint)
		{
			SAFE(paint();)
			SAFE(g_primary->blt(&place,g_backbuffer,&place);)
		}
	}
	int hit_line(int x,int y) const
	{
		using namespace ns_list;
		POINT pt={x,y};
		if(!PtInRect(&text_place,pt))
		{
			return -1;
		}
		RECT a={text_place.left,text_place.top,text_place.right,text_place.top+line_step};
		for(int i=0;i<visible_lines;++i,OffsetRect(&a,0,line_step))
		{
			if(PtInRect(&a,pt))
				return i;
		}
		return -1;
	}
	void draw_line(int pos,char * str,int st)
	{
		ENTER(wList::draw_line);
		using namespace ns_list;
		RECT a={text_place.left,text_place.top,text_place.right,text_place.top+line_step};
		OffsetRect(&a,0,line_step*pos);
		// invert background if needed
		if(st)g_backbuffer->invert(&a);
		// choose shadow color
		int col=0;
		switch(st)
		{	case 0:col=color_s1;break;
			case 1:col=color_s2;break;
			case 2:col=color_s3;break;	}
		OffsetRect(&a,1,-1);
		g_backbuffer->color(col);
		g_backbuffer->text(str,&a,DT_NOPREFIX);
		// choose textcolor
		switch(st)
		{	case 0:col=color_t1;break;
			case 1:col=color_t2;break;
			case 2:col=color_t3;break;	}
		OffsetRect(&a,-1,1);
		g_backbuffer->color(col);
		g_backbuffer->text(str,&a,DT_NOPREFIX);
		LEAVE();
	}
	wList()
		:wControl()
	{
		ENTER(wList::wList);
		g_viewport->remove_controls(1);//remove existing list if any
		assert(ns_list::current_list==NULL);//some static variables are shared by all list instances in application, so there can be only one
		surface=g_surfaces[2];surface->add_ref();
		memcpy(&place,&ns_list::place,sizeof(place));
		ns_list::current_list=(void*)this;
		tag=1;
		top_line=0;
		sel_line=0;
		sel_state=0;
		LEAVE();
	}
	virtual ~wList()
	{
		SAFE(surface->release();)
		ns_list::current_list=NULL;
	}
	void paint()
	{
		using namespace ns_list;
#ifdef _DEBUG
		assert(SUCCEEDED(g_backbuffer->blt(&place,g_surfaces[2],NULL)));
		assert(SUCCEEDED(g_backbuffer->begin_gdi()));
#else
		HRESULT hr;
		hr=g_backbuffer->blt(&place,g_surfaces[2],NULL);
		assert(SUCCEEDED(hr));
		hr=g_backbuffer->begin_gdi();
		assert(SUCCEEDED(hr));
#endif
		g_backbuffer->font(font);
		for(int i=0,j=top_line;(i<visible_lines)&&(j<n_items);++i,++j)
		{
			if(i==sel_line)
				draw_line(i,items[j],sel_state);
			else
				draw_line(i,items[j],0);
		}
#ifdef _DEBUG
		assert(SUCCEEDED(g_backbuffer->end_gdi()));
#else
		hr=g_backbuffer->end_gdi();
		assert(SUCCEEDED(hr));
#endif
	}
	void scroll_down()
	{
		using namespace ns_list;
		if(n_items>visible_lines)
		{
			if(n_items-top_line>visible_lines)
			{
				++top_line;
				SAFE(paint();)
				SAFE(g_primary->blt(&place,g_backbuffer,&place);)
			}
		}
	}
	void scroll_up()
	{
		using namespace ns_list;
		if(n_items>visible_lines)
		{
			if(top_line>0)
			{
				--top_line;
				SAFE(paint();)
				SAFE(g_primary->blt(&place,g_backbuffer,&place);)
			}
		}
	}
};
#
	using namespace ns_list;
	for(int i=0;i<argc;++i)
	{
		if(!strcmp(argv[i],"place"))
		{
			place.left=atoi(argv[i+1]);
			place.top=atoi(argv[i+2]);
			place.right=place.left+atoi(argv[i+3]);
			place.bottom=place.top+atoi(argv[i+4]);
			memcpy(&text_place,&place,sizeof(place));
			i+=4;
		}
		else if(!strcmp(argv[i],"load"))
		{
			wList * list=new wList;
			if(list->load(argv[i+1]))
			{
				g_viewport->insert(list);
				i+=1;
				g_viewport->paint();
			}
			else
				delete list;
		}
		else if(!strcmp(argv[i],"scroll_up"))
		{
			if(current_list)
			{
				((wList*)current_list)->scroll_up();
			}
		}
		else if(!strcmp(argv[i],"scroll_down"))
		{
			if(current_list)
			{
				((wList*)current_list)->scroll_down();
			}
		}
		else if(!strcmp(argv[i],"action"))
		{
			action=strdup(argv[i+1]);
			++i;
		}
		else GET_INT(line_step,line_step)
		else GET_INT(visible_lines,visible_lines)
		else GET_FONT(font,font)
		else GET_INT(c1t,color_t1)
		else GET_INT(c2t,color_t2)
		else GET_INT(c3t,color_t3)
		else GET_INT(c1s,color_s1)
		else GET_INT(c2s,color_s2)
		else GET_INT(c3s,color_s3)
	}	
	return 0;
}

bool wControl::is_topmost()
{
	return false;
}

void wViewport::insert_topmost(wControl *ptr)
{
	SAFE(assert(ptr->is_topmost());)
	SAFE(ptr->next=controls;)
	controls=ptr;
}

void wViewport::update()
{
	for(wControl * ptr=controls;ptr;ptr=ptr->next)
	{
		SAFE(ptr->update();)
	}
}

namespace ns_item
{
	char * base_name=0;
	int		item=0;
	RECT	_place={400,120,600,500},
			text_place={400,220,600,500},
			header_place={400,120,600,500};
	HFONT	text_font=0,
			header_font=0;
	int		text_color=0x00ffffff,
			header_color=0x00ff44aa;
	char	header_buf[512],
			text_buf[8192],
			object_buf[512],
			thumb_buf[512];
};

extern "C" __declspec(dllexport)
long exec_item(int argc,char **argv)
{
	if((int)ShellExecute(g_hWnd,0,ns_item::object_buf,0,0,SW_SHOW)<=32)
	{
		SAFE(ShellExecute(g_hWnd,0,"start",ns_item::object_buf,0,SW_HIDE);)
	}
	return 0;
}

extern "C" __declspec(dllexport)
long create_text_pad(int argc,char **argv)
{
#
	struct wTextPad : public wControl
	{
		wTextPad()
			:wControl()
		{
			SAFE(g_viewport->remove_controls(2);)
			using namespace ns_item;
			surface=g_surfaces[3];
			surface->add_ref();
			memcpy(&place,&_place,sizeof(place));
			tag=2;
		}
		~wTextPad()
		{
			surface->release();
		}
		void paint()
		{
			using namespace ns_item;
			SAFE(g_backbuffer->blt(&place,surface,0);)
#ifdef _DEBUG
			assert(SUCCEEDED(g_backbuffer->begin_gdi()));
#else
			HRESULT hr=g_backbuffer->begin_gdi();
			assert(SUCCEEDED(hr));
#endif
			//
			SAFE(g_backbuffer->color(header_color);)
			SAFE(g_backbuffer->font(header_font);)
			SAFE(g_backbuffer->text(header_buf,&header_place,DT_NOPREFIX|DT_WORDBREAK);)
			//
			SAFE(g_backbuffer->color(text_color);)
			SAFE(g_backbuffer->font(text_font);)
			SAFE(g_backbuffer->text(text_buf,&text_place,DT_NOPREFIX|DT_EXPANDTABS|DT_WORDBREAK);)
			//
#ifdef _DEBUG
			assert(SUCCEEDED(g_backbuffer->end_gdi()));
#else
			hr=g_backbuffer->end_gdi();
			assert(SUCCEEDED(hr));
#endif
		}
	};
#
	static char create_action[512];
	static char line[8192];
	using namespace ns_item;
	assert(argc==2);
	base_name=strdup(argv[0]);
	item=atoi(argv[1]);
	strcpy(header_buf,"undefined item");
	strcpy(text_buf,"description not available");
	strcpy(create_action,base_name);
	strcat(create_action,".txt");
	FILE * f=fopen(create_action,"rt");
	if(f)
	{
		fgets(line,8192,f);
		strcpy(create_action,line);
		unsigned char * p;
#define TRIM(s) for(p=(unsigned char*)s;*p;++p);while(*p<=32&&p>=(unsigned char*)s)*p--=0;
		TRIM(create_action)
		for(int i=0;i<=item;++i)
		{
			fgets(line,8192,f);TRIM(line)//exe
			strcpy(object_buf,line);
			fgets(line,8192,f);TRIM(line)//thumb
			strcpy(thumb_buf,line);
			fgets(line,8192,f);TRIM(line)//header
			strcpy(header_buf,line);
			fgets(line,8192,f);TRIM(line)//text
			strcpy(text_buf,line);
			for(char * ptr=text_buf;*ptr;++ptr)
			{
				if(*ptr=='\\'&&ptr[1]!=0)
				{
					switch(ptr[1])
					{
					case'n':case'N':
						{
							ptr[0]=32;
							ptr[1]=0xA;
						}
						break;
					case't':case'T':
						{
							ptr[0]=32;
							ptr[1]=9;
						}
						break;
					}
				}
			}
		}
#undef TRIM
		fclose(f);
	}
	wTextPad * tp=new wTextPad;
	SAFE(g_viewport->insert(tp);)
	if(f)
		SAFE(wCall(create_action);)
	SAFE(g_viewport->paint();)
	return 0;
}

extern "C" __declspec(dllexport)
long setup_text_pad(int argc,char **argv)
{
	using namespace ns_item;
	for(int i=0;i<argc;++i)
	{
		GET_FONT(text_font,text_font)
		else GET_FONT(header_font,header_font)
		else GET_RECT(place,_place)
		else GET_RECT(text_place,text_place)
		else GET_RECT(header_place,header_place)
		else GET_INT(text_color,text_color)
		else GET_INT(header_color,header_color)
	}
	return 0;
}

namespace ns_thumb
{
	char	* base_dir_t=".\\",
			* base_dir=".\\";
	char * base_name=ns_item::thumb_buf;
	RECT _place;
};

extern "C" __declspec(dllexport)
long thumb (int argc,char **argv)
{
#
	struct wThumb: public wControl
	{
		int index;
		int state;
		int color()
		{
			int col[3]={RGB(0,255,0),
						RGB(255,0,0),
						RGB(64,0,0)};
			if(state>=0&&state<=2)
				return col[state];
			__asm int 3;
			return 0;
		}
		wThumb(int idx)
			:wControl(),index(idx),state(0)
		{
			memcpy(&place,&ns_thumb::_place,sizeof(place));
			char path[256];
			SAFE(wsprintf(path,"%s%s%i.jpg",ns_thumb::base_dir_t,ns_thumb::base_name,idx);)
			SAFE(surface=g_driver2d->load_image(path,"JPEG");)
			if(surface==NULL)
			{
				SAFE(surface=g_driver2d->create_offscreen(24,24);)
				SAFE(surface->begin_gdi();)
				RECT mr={0,0,24,24};
				SAFE(surface->color(255);)
				SAFE(surface->text("N/A",&mr,0);)
				SAFE(surface->end_gdi();)
			}
		}
		void paint()
		{
			SAFE(g_backbuffer->blt(&place,surface,NULL);)

			SAFE(g_backbuffer->begin_gdi();)

			HDC dc;

			SAFE(dc=g_backbuffer->get_dc();)

			HPEN pen=CreatePen(PS_SOLID,0,color());
			HGDIOBJ op=SelectObject(dc,pen);

			MoveToEx(dc,place.left,place.top,NULL);

			LineTo(dc,place.right,place.top);
			LineTo(dc,place.right,place.bottom);
			LineTo(dc,place.left,place.bottom);
			LineTo(dc,place.left,place.top);

			SelectObject(dc,op);
			DeleteObject(pen);

			SAFE(g_backbuffer->end_gdi();)
		}
		void set_state(int ns)
		{
			if(ns!=state)
			{
				state=ns;
				paint();
				g_primary->blt(&place,g_backbuffer,&place);
			}
		}
		virtual ~wThumb()
		{
			surface->release();
		}
		void on_mousemove(int x,int y)
		{
			set_state(hit(x,y)?1:0);
		}
		void on_lbuttondown(int x,int y)
		{
			if(hit(x,y))
			{
	#
				struct wSplash: public wControl
				{
					wSplash(int idx)
						:wControl()
					{
						char path[256];
						wsprintf(path,"%s%s%i.jpg",ns_thumb::base_dir,ns_thumb::base_name,idx);
						surface=g_driver2d->load_image(path,"JPEG");
						if(surface==NULL)
						{
							surface=g_driver2d->create_offscreen(24,24);
							surface->begin_gdi();
							RECT mr={0,0,24,24};
							surface->color(255);
							surface->text("N/A",&mr,0);
							surface->end_gdi();
						}
						place.left=place.top=0;
						place.right=800;
						place.bottom=600;
						tag=9;
					}
					void paint()
					{
						g_backbuffer->blt(NULL,surface,NULL);
					}
					void on_lbuttondown(int x,int y)
					{
						g_viewport->remove_controls(9);
						g_viewport->paint();
					}
					void on_rbuttonup(int x,int y)
					{
						g_viewport->remove_controls(9);
						g_viewport->paint();
					}
					virtual ~wSplash()
					{
						surface->release();
					}
					bool is_topmost()
					{
						return true;
					}
				};
	#
#
					struct Anim
					{
						RECT	start,
								stop;
						Anim(RECT * r1,RECT * r2)
						{
							memcpy(&start,r1,sizeof(RECT));
							memcpy(&stop,r2,sizeof(RECT));
						}
						void operator () (RECT &r,int t)
						{
							for(long * p1=&start.left,*p2=&stop.left,*p=&r.left,i=0;i<4;++i,++p,++p1,++p2)
							{
								*p=((*p1)*(800-t)+(*p2)*t)/800;
							}
						}
					};
#
				wControl * sp;
				g_viewport->insert_topmost(sp=new wSplash(index));
				{
					DWORD t1=timeGetTime();
					Anim anim(&place,&sp->place);
					for(;timeGetTime()-t1<800;)
					{
						RECT r;
						int t=timeGetTime()-t1;
						if(t>800)t=800;
						anim(r,t);
						g_primary->blt(&r,sp->surface,NULL);
					}
				}
				g_viewport->paint();
			}
		}
	};
#
	wThumb * thumb;
	int idx=0;
	int tag=2;
	for(int i=0;i<argc;++i)
	{
		GET_RECT(place,ns_thumb::_place)
		else GET_INT(index,idx)
		else GET_INT(tag,tag)
		else GET_STR(dir_thumbs,ns_thumb::base_dir_t)
		else GET_STR(dir_screens,ns_thumb::base_dir);
	}
	SAFE(thumb=new wThumb(idx);)
	thumb->tag=tag;
	SAFE(g_viewport->insert(thumb);)
	SAFE(g_viewport->paint();)
	return 0;
}

void wControl::on_rbuttonup(int x, int y)
{

}

void wViewport::on_rbuttonup(int x, int y)
{
	if(controls->is_topmost())
	{
		SAFE(controls->on_rbuttonup(x,y);)
		return;
	}
	for(wControl * ptr=controls;ptr;ptr=ptr->next)
	{
		SAFE(ptr->on_rbuttonup(x,y);)
	}
}
