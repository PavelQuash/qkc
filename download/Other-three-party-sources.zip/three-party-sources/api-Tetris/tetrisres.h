#define	ID_NEW	1010
#define	ID_EXIT	1020
#define	ID_ABOUT	1030
#define	ID_HI		1040
#define	IDD_SCOREDIALOG	100
#define	IDNAME1	102
#define	IDNAME2	103
#define	IDNAME3	104
#define	IDNAME4	105
#define	IDNAME5	106
#define	IDSCORE1	107
#define	IDSCORE2	108
#define	IDSCORE3	109
#define	IDSCORE4	110
#define	IDSCORE5	111


