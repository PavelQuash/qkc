/* Weditres generated include file. Do NOT edit */
#define	IDD_MAINDIALOG	100
#define	IDB_SOCKET	101
#define	IDB_SEND	102
#define	IDB_RESV	103
#define	IDM_PORT	104
#define	IDE_IP	105
#define	IDE_RUN	107
#define	IDB_CON	109
#define	IDE_MSG	110
#define	IDB_SOCKETS	201
#define	IDB_SOCKETC	203
