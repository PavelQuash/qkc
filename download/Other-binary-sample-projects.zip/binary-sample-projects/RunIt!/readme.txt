		This is the readme file for RunIt!

Introduction
************

	Tired of opening million folders in Start menu hoping just to restart
you last executed application? Tired of navigating in Explorer directory tree 
in order to rerun your favourite program? Do you want to feel free? This is 
the program for you! It makes the same thing with applications that Windows 
makes with documents placing them in "Documents" submenu. Also RunIt! tracks 
your most frequently used programs. RunIt! saves your precious time and nerves 
because it allows you to restart applications with just two mouse clicks!

	Use cute "Run" window instead of awkward standard Windows' one!

	Now you can log all applications executions on your computer while
you are far away from it.

Overview
********

	RunIt! is a shell utility for Windows 95/98/Me/NT/2000/XP. Being executed,
RunIt! tracks the operation system. If any Windows' application starts, RunIt!
places a link to it ("track") in Recent Menu. Thus all executed application are 
tracked and tracks to them are placed in Recent Menu in natural order. Every 
track has an icon. You can restart any of them easily by selecting an adequate 
track from the menu.
	Every time you exit the program, it counts and saves information about 
most frequently used applications. This information is used to create Top100 
list. Several first items of that list can be placed in Top menu.

	RunIt! can log events, run programs and terminate hanged ones.

	To use RunIt! under Windows 95 you should install Internet Explorer 4 
or higher.

Files description
*****************

	The following files are situated both in RunIt! installation folder 
and in folder of current user

	\Favorites	- the folder that contains shortcuts for Favorites Menu
	\Cache		- the folder that contains cache and service files of RunIt!
	lb_normal.bmp	- bitmap of normal LaunchBand buttons
	lb_hilight.bmp	- bitmap of hilighted LaunchBand buttons
	Default.lng - English language file. You can edit it to your language
	DefaultIcons.idx - default icon exclusion index file
	DefaultIcons.dat - default icon exclusion data file
	file_id.diz - short description of RunIt!
	UserIcons.idx - icon exclusion index file
	UserIcons.dat - icon exclusion data file
	license.rus - license agreement for the program on russian
	license.txt - license agreement for the program
	Psapi.dll - library for Windows NT/2000 by Microsoft Corp.
	readme.txt - this file
	RunIt.chm - help file
	RunIt.exe - executable file of RunIt!
	RunIt.ini - initialization file
	RunIt.key - registration key (in registered copy)
	RunIt.lng - localized language file
	RunIt.log.old - saved log file
	RunIt.log - log file
	RunIt.url - RunIt! site link
	whatsnew.txt - what is new in RunIt!?
	Uninstall.exe - uninstall RunIt! executable file

Installation
************

	Simply start RunIt! archive executable file and follow installation
instructions.

Uninstallation
**************
       
	Open "Start\Control Panel\Add/Remove Programs", select "RunIt!" from 
the list and press "Ok" or just start Uninstall.exe from RunIt! folder.
  
To get detailed help on product, select "Help" from Actions Menu of RunIt!
